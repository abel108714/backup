﻿Imports System.Drawing.Text
Imports System.IO
Imports System.Text.RegularExpressions
'Imports Microsoft.Office.Interop.Excel

Public Class Form1
    Dim progPath As String
    Dim dataPath As String
    Dim dataPath2 As String
    Dim dataPath3 As String
    Dim autoCloseCheck As String
    Dim autoHideWin As String
    Public Property Listbox1 As Object

    Public Sub Form_load() Handles Me.Load
        Button1.Location = New Point((ClientSize.Width - Button1.Width) \ 2,
                             (ClientSize.Height - Button1.Height) \ 2)
        ' The following statement calls the Get procedure of the Visual Basic Now property.
        Label1.Text = System.DateTime.Now
        Label1.Visible = False
        Dim d1 As String = DateTime.Parse(Label1.Text).ToString("dd/MM/yyyy hh:mm:ss tt")

        'Me.MaximizeBox = False '關閉視窗最大化
        'Me.MinimizeBox = False '關閉視窗最小化
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.FixedSingle '固定視窗大小

        Dim str As Array
        Dim not_EOL_str As Array
        Dim fileReader As String
        Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Dim autoHideWin As String
        '讀取記錄及檢查檔案是否存在
        If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
            'MsgBox("檔案存在")
            fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
            not_EOL_str = Split(fileReader, vbCrLf)
            str = Split(not_EOL_str(1), "=")
            If String.Compare(str(0), "autoHideWin") = 0 Then
                autoHideWin = str(1)
                If autoHideWin = "True" Then
                    Try
                        Me.Visible = False '隱藏小工具介面
                        NotifyIcon1.Visible = True '左下角顯示
                        Button1_Click(Button1, New System.EventArgs()) '自動按下按鈕
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                End If
            End If
        Else
            'MsgBox("檔案不存在")
        End If

    End Sub
    Private Sub Form_resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Try
            If Me.WindowState = FormWindowState.Minimized Then
                Me.Visible = False
                NotifyIcon1.Visible = True
                'NotifyIcon1.ShowBalloonTip(1, "notifyIcon", "Running", ToolTipIcon.Info)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick
        Try
            Me.Visible = True
            Me.WindowState = FormWindowState.Normal
            NotifyIcon1.Visible = False
            'NotifyIcon1.ShowBalloonTip(1, "notifyIcon", "Running", ToolTipIcon.Info)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub 路徑設定ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 路徑設定ToolStripMenuItem.Click
        Dim inputFrom As New Form2
        inputFrom.Show()
        'Me.Dispose(False)
    End Sub

    Private Sub 離開ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 離開ToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        Try
            Me.Visible = True
            Me.WindowState = FormWindowState.Normal
            NotifyIcon1.Visible = False
            'NotifyIcon1.ShowBalloonTip(1, "notifyIcon", "Running", ToolTipIcon.Info)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim xlApp As Object
        Dim xlBook As Object
        Dim xlsheet As Object
        Dim str As Array
        Dim fileReader As String
        Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        '讀取記錄及檢查檔案是否存在
        Dim not_EOL_str As Array
        '讀取記錄及檢查檔案是否存在
        If File.Exists(mydocpath & Convert.ToString("\pathfile.txt")) Then
            'MsgBox("檔案存在")
            fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\pathfile.txt"), System.Text.Encoding.UTF8)
            not_EOL_str = Split(fileReader, vbCrLf)
            str = Split(not_EOL_str(0), "=")
            If String.Compare(str(0), "softpath") = 0 Then
                progPath = str(1)
            End If
            str = Split(not_EOL_str(1), "=")
            If String.Compare(str(0), "datapath") = 0 Then
                dataPath = str(1)
                dataPath2 = str(1)
                dataPath = str(1)
            End If
        Else
            'MsgBox("檔案不存在")
        End If

        'MsgBox("The formatted date is " & Format(#5/31/1993#, "dddd, d MMM yyyy"))
        'progPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Office\EXCEL.EXE"
        'dataPath = root & "2020-04-08-08-40-09_N每日業績N.xls"

        Dim thisDate1 As Date = #2020/04/08#
        'MsgBox(thisDate1.ToString("yyyy-MM-dd-") & "40-09")
        Dim str1 As String
        Dim str2 As String
        Dim str3 As String
        str1 = "2020-04-08-08-40-09_N每日業績N.xls     "
        str2 = "2020-04-08-" '1
        str3 = "_N每日業績N.xls" '20
        'MsgBox(InStr(1, str1, str2))
        'MsgBox(InStr(1, str1, str3))
        'MsgBox(InStr(1, str1, str2) >= 1)

        '' Step 1: create Regex.
        'Dim regex As Regex = New Regex("\d+")

        '' Step 2: call Match on Regex.
        'Dim match As Match = regex.Match("Dot 77 Perls")

        '' Step 3: test the Success bool.
        '' ... If we have Success, write the Value.
        'If match.Success Then
        '    MsgBox(match.Value)
        'End If
        Dim root As String = dataPath
        dataPath = dataPath & "\" & thisDate1.ToString("yyyy-MM-dd-") & "08-40-09" _ '"\d{4}-\d{2}-\d{2}")
& "_N每日業績N.xls"
        dataPath2 = thisDate1.ToString("yyyy-MM-dd-") & "08-40-09" _ '"\d{4}-\d{2}-\d{2}")
& "_N每日業績N.xls"
        '讀取記錄及檢查檔案是否存在
        'MsgBox(111)
        'If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
        '    'MsgBox("檔案存在")
        '    '讀取記錄及檢查檔案是否存在
        '    MsgBox(112)
        '    fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
        '    MsgBox(113)
        '    str = Split(fileReader, "=")
        '    MsgBox(str(0))
        '    MsgBox(str(1))
        '    If String.Compare(str(0), "autoCloseCheck") = 0 Then
        '        'MsgBox("str(1) : " & str(1))
        '        If str(1) = "True" Then
        '            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
        '        Else
        '            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = False
        '        End If
        '    End If

        'Else
        '    'MsgBox("檔案不存在")
        '    '儲存內容,檔案開頭
        '    'lines += "----------------------"
        '    'lines += vbCrLf
        '    'lines += "System Registry Editor"
        '    'lines += vbCrLf
        '    'lines += "----------------------"
        '    'lines += vbCrLf
        '    'lines += vbCrLf
        'End If
        'Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        'Dim str As Array
        'Dim fileReader As String
        Dim lines As String
        lines = ""
        'Dim not_EOL_str As Array
        'Dim fileReader As String
        'Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        '讀取記錄及檢查檔案是否存在
        If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
            'MsgBox("檔案存在")
            fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
            not_EOL_str = Split(fileReader, vbCrLf)
            str = Split(not_EOL_str(0), "=")
            'MsgBox(not_EOL_str(0))
            If String.Compare(str(0), "autoCloseCheck") = 0 Then
                'MsgBox(str(0))
                'MsgBox(str(1))
                autoCloseCheck = str(1)
                If str(1) = "True" Then
                    'MsgBox(0)
                    Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
                Else
                    'MsgBox(1)
                    Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = False
                End If
            End If
        Else
            'MsgBox("檔案不存在")
            'progPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Office\EXCEL.EXE"
            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
        End If
        If Dir(progPath) = "" Then '判斷EXCEL是否打開

            '先找指定名稱
            Try
                ' Only get files that begin with the letter "c." 
                Dim dir As String
                Dim dirs As String() = Directory.GetFiles(root, thisDate1.ToString("yyyy-MM-dd-") & "*.xls")
                'MsgBox(dirs.Length)

                For Each dir In dirs
                    'MsgBox(If(File.Exists(dir), "File exists.", "File does not exist."))
                Next
                If File.Exists(dir) And dirs.Length = 1 Then
                    'MsgBox(If(File.Exists(dir), "File exists.", "File does not exist."))
                    xlApp = CreateObject("Excel.Application") '創建EXCEL應用類
                    xlApp.Visible = True '設置EXCEL可見
                    xlBook = xlApp.Workbooks.Open(dir) '打開EXCEL工作簿
                    xlsheet = xlBook.Worksheets(1) '打開EXCEL第一頁工作表
                    xlsheet.Activate '啟動第一頁工作表
                    xlApp.Run("網通部門業績表") '第一個為sub名稱,第二個為要傳遞的參數
                    'xlBook.RunAutoMacros(Microsoft.Office.Interop.Excel.XlRunAutoMacro.xlAutoActivate) '運行EXCEL中的啟動宏
                    'xlBook.RunAutoMacros(Microsoft.Office.Interop.Excel.XlRunAutoMacro.xlAutoOpen)
                    'Microsoft.Office.Interop.Excel與new Point套件衝突不能引入
                    xlsheet = xlBook.Worksheets(2) '打開EXCEL第二頁工作表
                    xlsheet.Activate '啟動第二頁工作表

                Else
                    '若無，讓使用者選擇
                    MsgBox("無今日績效表或有兩個以上績效表，請另選檔案")
                    OpenFileDialog1.InitialDirectory = root
                    OpenFileDialog1.FileName = thisDate1.ToString("yyyy-MM-dd-")
                    OpenFileDialog1.Filter = "*|*.xls" '2020-04-08-08-40-09_N每日業績N.xls"
                    Dim r As Integer = OpenFileDialog1.ShowDialog()
                    If r = DialogResult.OK Then
                        xlApp = CreateObject("Excel.Application") '創建EXCEL應用類
                        xlApp.Visible = True '設置EXCEL可見
                        'System.Diagnostics.Process.Start(OpenFileDialog1.FileName) '執行
                        'xlBook = xlApp.Workbooks.Open(OpenFileDialog1.FileName) '打開EXCEL工作簿
                        xlBook = xlApp.Workbooks.Open(dataPath) '打開EXCEL工作簿
                        xlsheet = xlBook.Worksheets(1) '打開EXCEL第一頁工作表
                        xlsheet.Activate '啟動第一頁工作表
                        xlApp.Run("網通部門業績表") '第一個為sub名稱,第二個為要傳遞的參數
                        'xlBook.RunAutoMacros(Microsoft.Office.Interop.Excel.XlRunAutoMacro.xlAutoActivate) '運行EXCEL中的啟動宏
                        'xlBook.RunAutoMacros(Microsoft.Office.Interop.Excel.XlRunAutoMacro.xlAutoOpen)
                        'Microsoft.Office.Interop.Excel與new Point套件衝突不能引入
                        xlsheet = xlBook.Worksheets(2) '打開EXCEL第二頁工作表
                        xlsheet.Activate '啟動第二頁工作表
                    End If
                End If
                If Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked Then
                    'Dim str As Array
                    'Dim not_EOL_str As Array
                    'Dim fileReader As String
                    'Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                    Dim autoHideWin As String
                    '讀取記錄及檢查檔案是否存在
                    If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
                        'MsgBox("檔案存在")
                        fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
                        not_EOL_str = Split(fileReader, vbCrLf)
                        str = Split(not_EOL_str(1), "=")
                        If String.Compare(str(0), "autoHideWin") = 0 Then
                            autoHideWin = str(1)
                            'MsgBox(autoHideWin)
                            If autoHideWin = "True" Then
                                'MsgBox(0)
                                Try
                                    'MsgBox(1)
                                    Me.Visible = False '隱藏小工具介面
                                    Me.Hide()
                                    System.Windows.Forms.Application.DoEvents()
                                    NotifyIcon1.Visible = True '左下角顯示

                                    Me.Form1_Activated(AcceptButton, New System.EventArgs())
                                    'CreateObject(Me.Form1).MinimizeAll
                                    'Button1_Click(Button1, New System.EventArgs()) '自動按下按鈕
                                    'MsgBox(11)
                                Catch ex As Exception
                                    'MsgBox(2)
                                    MsgBox(ex.Message)
                                End Try
                            Else
                                Me.Close() '結束視窗
                            End If
                        End If
                    Else
                        'MsgBox("檔案不存在")
                    End If

                End If
            Catch ex As Exception
                Console.WriteLine("The process failed: {0}", ex.ToString())
            End Try

        Else
            MsgBox("EXCEL已打開")
        End If

    End Sub
    Private Sub Form1_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        Me.Visible = False
    End Sub


    Private Sub 開啟檔案自動結束視窗ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 開啟檔案自動結束視窗ToolStripMenuItem.Click

        Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Dim str As Array
        Dim fileReader As String
        Dim lines As String
        lines = ""
        If Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True Then
            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = False
        Else
            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
        End If

        '讀取記錄及檢查檔案是否存在
        If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
            'MsgBox("檔案存在")
            fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
            str = Split(fileReader, "=")
            'MsgBox(String.Compare(str(0), "autoCloseCheck "))
            If String.Compare(str(0), "autoCloseCheck ") = 0 Then
                If str(1) = "True" Then
                    'Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
                Else
                    'Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = False
                End If
            End If
        Else
            'MsgBox("檔案不存在")

            '儲存內容,檔案開頭
            'lines += "----------------------"
            'lines += vbCrLf
            'lines += "System Registry Editor"
            'lines += vbCrLf
            'lines += "----------------------"
            'lines += vbCrLf
            'lines += vbCrLf
        End If

        '儲存內容
        lines += "autoCloseCheck=" & Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked

        '儲存記錄
        Using outputFile As New StreamWriter(mydocpath & Convert.ToString("\autoCloseCheck.txt"))
            outputFile.Write(lines)
            str = Split(lines, "=")
            If str(0) = "autoCloseCheck" Then
                'MsgBox(str(1))
            End If
        End Using

        '讀取記錄
        fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
        'MsgBox(fileReader)
        str = Split(fileReader, "=")
        If String.Compare(str(0), "autoCloseCheck ") = 0 Then
            'MsgBox("true")
        End If

        '儲存記錄
        'Dim lines As String
        '儲存內容
        lines = "autoCloseCheck=" & Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked
        lines += vbCrLf
        lines += "autoHideWin=" & Me.不顯示小工具介面ToolStripMenuItem.Checked
        MsgBox(lines)
        'Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Using outputFile As New StreamWriter(mydocpath & Convert.ToString("\autoCloseCheck.txt"))
            For Each line As String In lines
                outputFile.Write(line)
            Next
        End Using

    End Sub

    Private Sub 設定ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 設定ToolStripMenuItem.Click
        Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Dim str As Array
        Dim fileReader As String
        Dim lines As String
        lines = ""
        'Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        '讀取記錄及檢查檔案是否存在
        'If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
        '    'MsgBox("檔案存在")
        '    'Dim str As Array
        '    'Dim fileReader As String
        '    fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
        '    str = Split(fileReader, "=")
        '    If String.Compare(str(0), "autoCloseCheck") = 0 Then
        '        If String.Compare(str(1), "True") = 0 Then
        '            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
        '        Else
        '            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = False
        '        End If
        '    End If
        'Else
        '    'MsgBox("檔案不存在")
        '    Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
        '    '儲存內容
        '    lines += "autoCloseCheck=" & Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked
        '    '儲存記錄
        '    Using outputFile As New StreamWriter(mydocpath & Convert.ToString("\autoCloseCheck.txt"))
        '        outputFile.Write(lines)
        '    End Using
        'End If

        'Dim str As Array
        Dim not_EOL_str As Array
        'Dim fileReader As String
        'Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        '讀取記錄及檢查檔案是否存在
        If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
            'MsgBox("檔案存在")
            fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
            not_EOL_str = Split(fileReader, vbCrLf)
            str = Split(not_EOL_str(0), "=")
            If String.Compare(str(0), "autoCloseCheck") = 0 Then
                autoCloseCheck = str(1)
                If str(1) = "True" Then
                    Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
                Else
                    Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = False
                End If
            End If
        Else
            'MsgBox("檔案不存在")
            'progPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Office\EXCEL.EXE"
            Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked = True
        End If

        '讀取記錄及檢查檔案是否存在
        If File.Exists(mydocpath & Convert.ToString("\autoCloseCheck.txt")) Then
            'MsgBox("檔案存在")
            fileReader = My.Computer.FileSystem.ReadAllText(mydocpath & Convert.ToString("\autoCloseCheck.txt"), System.Text.Encoding.UTF8)
            not_EOL_str = Split(fileReader, vbCrLf)
            str = Split(not_EOL_str(1), "=")
            If String.Compare(str(0), "autoHideWin") = 0 Then
                autoHideWin = str(1)
                If str(1) = "True" Then
                    Me.不顯示小工具介面ToolStripMenuItem.Checked = True
                Else
                    Me.不顯示小工具介面ToolStripMenuItem.Checked = False
                End If
            End If
        Else
            'MsgBox("檔案不存在")
            'autoHideWin = "S:\網通部\◎資訊\data\績效資料\"
            Me.不顯示小工具介面ToolStripMenuItem.Checked = False
        End If

    End Sub

    Private Sub 不顯示小工具介面ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 不顯示小工具介面ToolStripMenuItem.Click

        If Me.不顯示小工具介面ToolStripMenuItem.Checked = True Then
            Me.不顯示小工具介面ToolStripMenuItem.Checked = False
        Else
            Me.不顯示小工具介面ToolStripMenuItem.Checked = True
        End If
        '儲存記錄
        Dim lines As String
        '儲存內容
        lines = "autoCloseCheck=" & Me.開啟檔案自動結束視窗ToolStripMenuItem.Checked
        lines += vbCrLf
        lines += "autoHideWin=" & Me.不顯示小工具介面ToolStripMenuItem.Checked

        Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Using outputFile As New StreamWriter(mydocpath & Convert.ToString("\autoCloseCheck.txt"))
            For Each line As String In lines
                outputFile.Write(line)
            Next
        End Using
    End Sub

End Class
